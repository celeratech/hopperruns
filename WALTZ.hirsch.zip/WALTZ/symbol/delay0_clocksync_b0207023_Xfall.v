//Celera:delay0_clocksync_b0207023_Xfall
//TYPE:fixed 1us EDGE:fall DFT:no ACC:no
module delay0_clocksync_b0207023_Xfall (i,CELV,o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

