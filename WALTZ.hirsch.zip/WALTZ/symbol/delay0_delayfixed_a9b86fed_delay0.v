//Celera:delay0_delayfixed_a9b86fed_delay0
//TYPE:fixed 10us EDGE:fall DFT:no ACC:no
module delay0_delayfixed_a9b86fed_delay0 (i,CELV,o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

