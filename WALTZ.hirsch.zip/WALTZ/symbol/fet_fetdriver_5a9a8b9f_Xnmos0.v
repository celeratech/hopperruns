//Celera:fet_fetdriver_5a9a8b9f_Xnmos0
//Celera Confidential Symbol Generator
//power NMOS:Ron:4.000 Ohm
//Vgs 6V Vds 6V
//Kelvin:no

module fet_fetdriver_5a9a8b9f_Xnmos0 (GATE,SOURCE,DRAIN,NMOSiso6,SUB);
input GATE;
inout SOURCE;
inout DRAIN;
input SUB;
input NMOSiso6;
endmodule

