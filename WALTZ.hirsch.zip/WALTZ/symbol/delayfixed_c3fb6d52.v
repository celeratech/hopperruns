//Celera:delayfixed_c3fb6d52
//Celera Confidential Symbol Generator
//TYPE:fixed Egde:rise
module delayfixed_c3fb6d52 (CELV,i,o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELG;
input CELSUB;
endmodule

