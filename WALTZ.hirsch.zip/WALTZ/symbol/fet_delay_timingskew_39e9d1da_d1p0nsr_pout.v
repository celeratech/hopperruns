//Celera:fet_delay_timingskew_39e9d1da_d1p0nsr_pout
//Celera Confidential Symbol Generator
//signal
//Vds 6V
module fet_delay_timingskew_39e9d1da_d1p0nsr_pout (GATE,DRAIN,SOURCE,
PMOSiso6,CELSUB);
input PMOSiso6;
input GATE;
inout SOURCE;
inout DRAIN;
input CELSUB;
endmodule

