//Celera:clocksync_b0207023
//Celera Confidential Symbol Generator
//VMAX:6FREQ:600KHz DUTY:30%-70%
module clocksync_b0207023 (CELV,clocksync_in,clk,enable_clocksync,global_clocksync,clocksync_out,
clocksync_high,
clocksync_low,
CELG,CELSUB);
input CELV;
input clocksync_in;
input clk;
input enable_clocksync;
input global_clocksync;
output clocksync_out;
output clocksync_high;
output clocksync_low;
input CELG;
input CELSUB;
endmodule

