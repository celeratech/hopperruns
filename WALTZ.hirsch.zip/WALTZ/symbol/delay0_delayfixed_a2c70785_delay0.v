//Celera:delay0_delayfixed_a2c70785_delay0
//TYPE: fixed 50ns
module delay0_delayfixed_a2c70785_delay0 (i, CELV, o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

