//Celera:delay0_delayfixed_9ff9934a_delay0
//TYPE: fixed 20ns
module delay0_delayfixed_9ff9934a_delay0 (i, CELV, o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

