//Celera:delay0_delayfixed_000809b0_delay0
//TYPE:fixed 100us EDGE:rise DFT:no ACC:no
module delay0_delayfixed_000809b0_delay0 (i,CELV,o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

