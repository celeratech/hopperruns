//Celera:delay0_paddigitalinput_a0a43d6f_Xglitch
//TYPE: fixed 50ns
module delay0_paddigitalinput_a0a43d6f_Xglitch (i, CELV, o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

