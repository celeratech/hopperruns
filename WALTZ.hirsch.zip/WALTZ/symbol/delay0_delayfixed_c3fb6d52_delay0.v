//Celera:delay0_delayfixed_c3fb6d52_delay0
//TYPE:fixed 20us EDGE:rise DFT:no ACC:no
module delay0_delayfixed_c3fb6d52_delay0 (i,CELV,o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

