//Celera:delay0_delayfixed_ebbb3bf3_delay0
//TYPE: fixed 30ns
module delay0_delayfixed_ebbb3bf3_delay0 (i, CELV, o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

