//Celera:paddigitalinput_a0a43d6f
//Celera Confidential Symbol Generator
//PAD Digital Input //Filter Time:50ns
module paddigitalinput_a0a43d6f (SIMPV,CELV,IN,out,
CELG,CELSUB); 
input SIMPV;
input CELV;
input IN;
output out;
input CELG;
input CELSUB;
endmodule

