//Celera:resistordivider_vbuffer_6d6a9075_Xrfb
//Celera Confidential Symbol Generator
//VMAX:6V R:200.0KOhm 1Taps
module resistordivider_vbuffer_6d6a9075_Xrfb (TOP,
TAP0,
CELG, BOTTOM);
inout TOP;
output TAP0;
input CELG;
inout BOTTOM;
endmodule

