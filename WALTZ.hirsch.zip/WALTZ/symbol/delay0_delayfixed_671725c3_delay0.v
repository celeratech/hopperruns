//Celera:delay0_delayfixed_671725c3_delay0
//TYPE:fixed 10us EDGE:rise DFT:no ACC:no
module delay0_delayfixed_671725c3_delay0 (i,CELV,o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

