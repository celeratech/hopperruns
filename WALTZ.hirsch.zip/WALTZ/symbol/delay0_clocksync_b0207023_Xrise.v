//Celera:delay0_clocksync_b0207023_Xrise
//TYPE:fixed 1us EDGE:rise DFT:no ACC:no
module delay0_clocksync_b0207023_Xrise (i,CELV,o,
CELG,CELSUB);
input CELV;
input i;
output o;
input CELSUB;
input CELG;
endmodule

