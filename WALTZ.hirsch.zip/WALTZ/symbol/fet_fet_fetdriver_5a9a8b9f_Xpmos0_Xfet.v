//Celera:fet_fet_fetdriver_5a9a8b9f_Xpmos0_Xfet
//Celera Confidential Symbol Generator
//power PMOS:Ron:8.000 Ohm
//Vgs 6V Vds 6V
//Kelvin:no

module fet_fet_fetdriver_5a9a8b9f_Xpmos0_Xfet (GATE,SOURCE,DRAIN,PMOSiso6,SUB);
input GATE;
inout SOURCE;
inout DRAIN;
input SUB;
input PMOSiso6;
endmodule

